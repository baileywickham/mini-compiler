package ast;

public class IntType
   implements Type
{
}
