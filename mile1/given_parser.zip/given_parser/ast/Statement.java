package ast;

public interface Statement
{
}
