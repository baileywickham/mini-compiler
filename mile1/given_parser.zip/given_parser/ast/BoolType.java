package ast;

public class BoolType
   implements Type
{
}
