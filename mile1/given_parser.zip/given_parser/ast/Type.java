package ast;

public interface Type
{
}
