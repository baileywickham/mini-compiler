package ast;

public interface Expression
{
}
