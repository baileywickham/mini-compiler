package ast;

public class VoidType
   implements Type
{
}
