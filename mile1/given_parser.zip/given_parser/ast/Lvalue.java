package ast;

public interface Lvalue
{
}
